var s;const t=((s=globalThis.__sveltekit_tyqgxe)==null?void 0:s.base)??"";var e;const a=((e=globalThis.__sveltekit_tyqgxe)==null?void 0:e.assets)??t;export{a,t as b};
